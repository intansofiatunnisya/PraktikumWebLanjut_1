<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Selamat Datang</title>
</head>
<body>
	<h1>Praktikum Pemrograman Web Lanjut</h1>
</body>
</html>