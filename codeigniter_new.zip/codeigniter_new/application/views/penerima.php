<?php
echo "Data Yang Diterima Adalah ". $test;
?>