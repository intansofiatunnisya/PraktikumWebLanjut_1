<?php
class User extends CI_Controller 
{
	public function add()
	{
		$this->load->view('user_add');
	}
}